#/Nota: Devido a vários imprevistos furante o semestre fui incapaz de realizar a tarefa como foi desejado, peço desculpas pelo ocorrido. O programa está feito, porém sem as partes que não consegui realizar...


arq = open("Anexo_Arquivo_Dados_projeto_Logica_e_programacao_de_computadores.csv", "r")
for linha in arq:
    print(linha)
arq.close()

#//////////////////////////////////////////////// Área de input do usuário:

mes_inicial = int(input('Digite o mês inicial(1 a 12): ')) #Nota: Permiti a possibilidade de digitar o mês e ano corretos:
if mes_inicial > 12 or mes_inicial < 1:
   mes_inicial = int(input('Digite o mês inicial(1 a 12): '))
else:
  mes_final = int(input('Digite o mês final(1 a 12): '))
if mes_final > 12 or mes_final < 1:
   mes_final = int(input('Digite o mês final(1 a 12): '))
else:
  ano_inicial = int(input('Digite o ano inicial (1961 a 2016): '))
if ano_inicial > 2016 or ano_inicial < 1961:
   ano_inicial = int(input('Digite o ano inicial (1961 a 2016): '))
else:
  ano_final = int(input('Digite o ano final (1961 a 2016): '))
if ano_final > 2016 or ano_final < 1961:
   ano_final = int(input('Digite o ano final (1961 a 2016): '))
else:
   escolha = int(input("Como gostaria de ver as listas? Ver todos os dados (opção 1)? Apenas os de precipitação (opção 2)? apenas os de temperaatura(opção 3)? Ou apenas os de umidade de vento (opção 4)?"))
if escolha < 1 or escolha > 4:
    escolha = int(input("Como gostaria de ver as listas? Ver todos os dados (opção 1)? Apenas os de precipitação (opção 2)? apenas os de temperaatura(opção 3)? Ou apenas os de umidade de vento (opção 4)?"))
else:
#//////////////////////////////////////////////// subtuplas:
    print('gerando')
lista_dados = [] #Não sabia ao certo como implementar o arquivo em uma lista e manipulá-lo... 
lista_precip = []
lista_temp = []
lista_res =[]

#////////////////////////////////////////////////variáveis:

if escolha == 1: 
   for item in lista_dados:
      print(lista_dados) #caso o usuário escolhessea opção 1 a lista completa seria mostrada:
elif escolha == 2:
   for item in lista_dados:
      lista_precip.append(item[1])
      print(lista_precip) #opção 2
elif escolha == 3:
   for item in lista_dados:
      lista_temp.append((item[2], item[3], item[5]))
      print(lista_temp) #opção 3
else:
   for item in lista_dados:
      lista_res.append((item[6], item[7])) #opção 3

#///////////////////////////////////////////////////////////////////////////////////////////////

#O restante das etapas infelizmente não era possível realizar sem os dados. Novamente peço desculpas por não poder apresentar um trabalho bem construído. Não acontecerá novamente...